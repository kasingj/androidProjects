james Kasinger
kasingj@students.wwu.edu
appName: artistOrAnimator

description: This application is a demonstration of 2 different kinds of animation: Tween animation where transformations are being done onto the image views, and also hand drawing animation. The user has the choice of what kind of animation he/she chooses to do.  

notes: Screen orientation is locked in portrait mode. Hand drawing example was adapted from the handrawing example provided on canvas, as well as android documentation, tutorials etc. 

