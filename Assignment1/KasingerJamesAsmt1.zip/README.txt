James Kasinger
<kasingj@students.wwu.edu>
App Name: EuroCapitals

Purpose: This is a flashcard app for learning European countries and their capital cities. 

Note: the only 2 controls are Show (the capital) and Next (country). Countries are chosen at random from a list of all countries in Europe.